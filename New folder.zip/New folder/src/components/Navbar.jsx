import React from 'react'

function Navbar() {
  return (
    <div className='bg-slate-600'>
        <h1>Hello</h1>
    </div>
  )
}

export default Navbar
